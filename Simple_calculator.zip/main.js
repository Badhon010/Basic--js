function calculate(operation) {
  const number1 = parseFloat(document.getElementById("number1").value);
  const number2 = parseFloat(document.getElementById("number2").value);
  let result;
  if (operation === "add") {
    result = number1 + number2;
  } else if (operation === "subtract") {
    result = number1 - number2;
  } else if (operation === "multiply") {
    result = number1 * number2;
  } else if (operation === "divide") {
    result = number2 !== 0 ? number1 / number2 : "Cannot divide by zero";
  } else if (operation === "power") {
    result = Math.pow(number1, number2);
  } else if (operation === "modulus") {
    result = number1 % number2;
  } else {
    result = "Invalid operation";
  }
document.getElementById("result").textContent = "Result: " + result;
}