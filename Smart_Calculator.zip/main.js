const screen = document.querySelectorAll(".screen")[0], btns = document.querySelectorAll(".btns")[0];
// Creating my buttns
function btnAdd(icon) {
    let btn = document.createElement("button");
    btn.innerText = icon
    btns.appendChild(btn)
}
let icons = ["AC", "C", "%", '÷', '7', '8', '9', '×', '4', '5', '6', '-', '1', '2', '3', '+','0','(',')','^','00', '.', '='];
for (let i = 0; i < icons.length; i++) {
    let icon = icons[i];
    btnAdd(icon);
}

let t;
for (let i = 0; i < icons.length; i++) {
    t = document.querySelectorAll(".btns button")[i]
    if(t.innerText=='='){
        t.className=("ev")
    }else if(t.innerText=='AC'||t.innerText=='C'||t.innerText=='%'){
        t.className=("op") 
    }else if(t.innerText=='÷'||t.innerText=='×'||t.innerText=='-'||t.innerText=='+'||t.innerText=='^'){
        t.className=("np")
    }else if(t.innerText!='='){
        t.className=("nv")
    }
}
for (let i = 0; i < icons.length; i++) {
    document.querySelectorAll(".btns button")[i].addEventListener("click", () => {
        t = document.querySelectorAll(".btns button")[i]
        if(t.innerText=='='){
            try {
                screen.innerText = eval(screen.innerText.replace('÷','/').replace('×','*').replace('%','*0.01*').replace('^','**'))
            } catch (error) {
                screen.innerText = 'ERROR'
            }
        }
        else if(t.innerText=='AC'){
            screen.innerText = 0;
        }
        else if(t.innerText=='C'){
            if (screen.innerText.length==1) {
                screen.innerText = 0;
            } else {
                screen.innerText = screen.innerText.slice(0,-1);
            }
        }
        else if (screen.innerText == "0" || screen.innerText == 'ERROR') {
            screen.innerText = t.innerText;
            console.log(t.innerText)
        }
        else{
            screen.innerText += t.innerText;
        }
    })
}
t=true;
document.getElementById('color').addEventListener("click",()=>{
    t=!t
    if (t==false) {
        document.getElementsByTagName('main')[0].className="bm"
    } else {
        document.getElementsByTagName('main')[0].className=""
    }
    console.log(document.getElementsByTagName('main')[0].className)
})